Commandline
===========

.. argparse::
   :module: indicnlp.cli.cliparser
   :func: get_parser
   :prog: cliparser.py

