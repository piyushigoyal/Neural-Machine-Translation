transliterate Package
=====================

:mod:`sinhala_transliterator` Module
------------------------------------

.. automodule:: indicnlp.transliterate.sinhala_transliterator
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`unicode_transliterate` Module
-----------------------------------

.. automodule:: indicnlp.transliterate.unicode_transliterate
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`acronym_transliterator` Module
-----------------------------------

.. automodule:: indicnlp.transliterate.acronym_transliterator
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`script_unifier` Module
-----------------------------------

.. automodule:: indicnlp.transliterate.script_unifier
    :members:
    :undoc-members:
    :show-inheritance:
